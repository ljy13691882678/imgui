/**
 * T3网络验证 Android 示例
 * 官网: https://www.t3yanzheng.com
 *
 * 演示功能：公告显示、版本号判断、卡密登录
 * 纯代码构建 UI，兼容 AIDE 编译，无 XML 布局依赖
 *
 * 【使用方法】
 * 1. 修改下方 initRsa() / init() 中的调用码、密钥、公钥为您的程序配置
 * 2. 修改 LOCAL_VERSION 为您的本地版本号
 * 3. 编译运行即可
 */

package com.t3yanzheng.example;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // ============================================================
    // ↓↓↓ 在此处修改您的程序配置 ↓↓↓
    // ============================================================

    // 本地版本号（用于与服务端版本号对比）
    private static final String LOCAL_VERSION = "1000";

    // 主题色
    private static final int COLOR_PRIMARY = Color.parseColor("#6C63FF");
    private static final int COLOR_PRIMARY_DARK = Color.parseColor("#5A52E0");
    private static final int COLOR_ACCENT = Color.parseColor("#FF6584");
    private static final int COLOR_BG = Color.parseColor("#F0F2F5");
    private static final int COLOR_CARD = Color.parseColor("#FFFFFF");
    private static final int COLOR_TEXT_PRIMARY = Color.parseColor("#1A1A2E");
    private static final int COLOR_TEXT_SECONDARY = Color.parseColor("#6B7280");
    private static final int COLOR_TEXT_HINT = Color.parseColor("#9CA3AF");
    private static final int COLOR_SUCCESS = Color.parseColor("#10B981");
    private static final int COLOR_WARNING = Color.parseColor("#F59E0B");
    private static final int COLOR_ERROR = Color.parseColor("#EF4444");
    private static final int COLOR_DIVIDER = Color.parseColor("#E5E7EB");
    private static final int COLOR_INPUT_BG = Color.parseColor("#F9FAFB");
    private static final int COLOR_INPUT_BORDER = Color.parseColor("#D1D5DB");

    // SDK 实例
    private T3Verify verify;
    private Handler mainHandler;

    // 心跳定时器
    private static final int HEARTBEAT_INTERVAL = 60 * 1000; // 60秒
    private static final int MAX_HEARTBEAT_FAIL = 5;         // 最大连续失败次数
    private int heartbeatFailCount = 0;
    private Handler heartbeatHandler;
    private Runnable heartbeatRunnable;
    private String savedCard;
    private String savedStateCode;

    // 卡密本地存储 key
    private static final String PREF_NAME = "t3_verify";
    private static final String KEY_CARD = "saved_card";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 状态栏沉浸
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(COLOR_BG);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        mainHandler = new Handler(Looper.getMainLooper());

        // ============================================================
        // 初始化 SDK
        // ============================================================
        verify = new T3Verify();

        // 初始化方式一：Base64自定义编码集算法
        // verify.init(
        //     "364BB9C878698A91",           // 单码登录调用码
        //     "4AD6AF47E16C2641",           // 公告调用码
        //     "6DEFFB0C83B0113C",           // 版本号调用码
        //     "6653C56842BB614E",           // 心跳调用码
        //     "7b16d44d7af6f7762052a2ebe3020584", // APPKEY
        //     "__BASE64_CHARSET__" // Base64字符集
        // );

        // 初始化方式二：RSA 算法 + HEX 编码
        verify.initRsa(
            "364BB9C878698A91",           // 单码登录调用码
            "4AD6AF47E16C2641",           // 公告调用码
            "6DEFFB0C83B0113C",           // 版本号调用码
            "6653C56842BB614E",           // 心跳调用码
            "7b16d44d7af6f7762052a2ebe3020584", // APPKEY
            "-----BEGIN PUBLIC KEY-----\n" +
            "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCW0id/+Q1XLTATn6vnSNVHYSd6\n" +
            "c+LNukHq3xy+Boa6wX9Mj7fA0++4UyHrYavwLWqYd6i6dpd4Udb4JNoynwJ6gDVb\n" +
            "lENn1r1dFhORWqjBHTY2zEjK76IJU8GS1u6NFTWJsvB9Db5paTfIjfSJHRcbeX25\n" +
            "P2M3PQfwMNqIR8AwYwIDAQAB\n" +
            "-----END PUBLIC KEY-----"
        );

        /* 使用 RSA 算法时，请确保后台做如下配置:
         * 1. 传输配置-加密配置-全局加解密-开启
         * 2. 传输配置-加密配置-加密算法-RSA算法
         * 3. 传输配置-加密配置-请求值加密-开启
         * 4. 传输配置-加密配置-请求值编码-HEX编码(16进制)
         * 5. 传输配置-加密配置-返回值加密-开启
         * 6. 传输配置-校验配置-时间戳校验-开启
         * 7. 传输配置-校验配置-签名校验-双向签名
         * 8. 传输配置-校验配置-返回值配置-返回值格式-JSON
         * 9. 传输配置-校验配置-返回值配置-JSON返回时间戳-开启
         * 10. 传输配置-校验配置-返回值配置-JSON_CODE类型-int
         */

        // 构建主界面
        setContentView(buildMainScreen());

        // 检查是否有保存的卡密，尝试自动登录
        String localCard = loadCard();
        if (localCard != null && !localCard.isEmpty()) {
            tryAutoLogin(localCard);
        } else {
            showVerifyDialog();
        }
    }

    // ============================================================
    // 自动登录（使用保存的卡密）
    // ============================================================

    private void tryAutoLogin(final String card) {
        // 显示加载提示
        final AlertDialog loading = new AlertDialog.Builder(this)
                .setMessage("正在自动登录...")
                .setCancelable(false)
                .create();
        loading.show();

        final String machineCode = getDeviceId();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final T3Verify.T3LoginResult result = verify.login(card, machineCode);
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        loading.dismiss();
                        if (result.success) {
                            onLoginSuccess(card, result);
                        } else {
                            // 自动登录失败，清除保存的卡密，手动输入
                            clearCard();
                            Toast.makeText(MainActivity.this,
                                    "自动登录失败: " + result.error, Toast.LENGTH_LONG).show();
                            showVerifyDialog();
                        }
                    }
                });
            }
        }).start();
    }

    // ============================================================
    // 卡密本地存储
    // ============================================================

    private void saveCard(String card) {
        getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit()
                .putString(KEY_CARD, card).apply();
    }

    private String loadCard() {
        return getSharedPreferences(PREF_NAME, MODE_PRIVATE)
                .getString(KEY_CARD, null);
    }

    private void clearCard() {
        getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit()
                .remove(KEY_CARD).apply();
    }



    // ============================================================
    // 主界面（验证通过前的占位）
    // ============================================================

    private View buildMainScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(COLOR_BG);
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView hint = new TextView(this);
        hint.setText("验证完成后进入此界面");
        hint.setTextSize(16);
        hint.setTextColor(COLOR_TEXT_HINT);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint);
        return root;
    }

    // ============================================================
    // 验证弹窗
    // ============================================================

    private void showVerifyDialog() {
        // 最外层 ScrollView
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(COLOR_BG);
        scrollView.setFillViewport(true);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(20), dp(24), dp(20), dp(24));

        // ---- 顶部标题区 ----
        LinearLayout headerLayout = new LinearLayout(this);
        headerLayout.setOrientation(LinearLayout.VERTICAL);
        headerLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        headerLayout.setPadding(0, 0, 0, dp(20));

        // LOGO 圆形
        TextView logo = new TextView(this);
        logo.setText("T3");
        logo.setTextSize(22);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setTextColor(Color.WHITE);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setShape(GradientDrawable.OVAL);
        logoBg.setColors(new int[]{COLOR_PRIMARY, COLOR_PRIMARY_DARK});
        logoBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        logo.setBackground(logoBg);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(52), dp(52));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        logo.setLayoutParams(logoParams);
        headerLayout.addView(logo);

        // 标题
        TextView title = new TextView(this);
        title.setText("T3 网络验证");
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(COLOR_TEXT_PRIMARY);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(10), 0, dp(2));
        headerLayout.addView(title);

        // 副标题
        TextView subtitle = new TextView(this);
        subtitle.setText("请输入卡密完成验证");
        subtitle.setTextSize(13);
        subtitle.setTextColor(COLOR_TEXT_SECONDARY);
        subtitle.setGravity(Gravity.CENTER);
        headerLayout.addView(subtitle);

        container.addView(headerLayout);

        // ---- 公告卡片 ----
        LinearLayout noticeCard = createCard();

        // 公告标题行
        LinearLayout noticeTitleRow = new LinearLayout(this);
        noticeTitleRow.setOrientation(LinearLayout.HORIZONTAL);
        noticeTitleRow.setGravity(Gravity.CENTER_VERTICAL);
        noticeTitleRow.setPadding(0, 0, 0, dp(8));

        // 小圆点指示器
        View noticeDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(COLOR_WARNING);
        noticeDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(8), dp(8));
        dotParams.setMargins(0, 0, dp(8), 0);
        noticeDot.setLayoutParams(dotParams);
        noticeTitleRow.addView(noticeDot);

        TextView noticeTitle = new TextView(this);
        noticeTitle.setText("公告");
        noticeTitle.setTextSize(14);
        noticeTitle.setTypeface(Typeface.DEFAULT_BOLD);
        noticeTitle.setTextColor(COLOR_TEXT_PRIMARY);
        noticeTitleRow.addView(noticeTitle);
        noticeCard.addView(noticeTitleRow);

        // 公告内容
        final TextView noticeContent = new TextView(this);
        noticeContent.setText("正在加载...");
        noticeContent.setTextSize(13);
        noticeContent.setTextColor(COLOR_TEXT_SECONDARY);
        noticeContent.setLineSpacing(dp(3), 1);
        noticeContent.setMaxLines(5);
        noticeCard.addView(noticeContent);

        container.addView(noticeCard);

        // ---- 版本信息卡片 ----
        LinearLayout versionCard = createCard();

        // 版本标题行
        LinearLayout versionTitleRow = new LinearLayout(this);
        versionTitleRow.setOrientation(LinearLayout.HORIZONTAL);
        versionTitleRow.setGravity(Gravity.CENTER_VERTICAL);
        versionTitleRow.setPadding(0, 0, 0, dp(8));

        View versionDot = new View(this);
        GradientDrawable vDotBg = new GradientDrawable();
        vDotBg.setShape(GradientDrawable.OVAL);
        vDotBg.setColor(COLOR_PRIMARY);
        versionDot.setBackground(vDotBg);
        LinearLayout.LayoutParams vDotParams = new LinearLayout.LayoutParams(dp(8), dp(8));
        vDotParams.setMargins(0, 0, dp(8), 0);
        versionDot.setLayoutParams(vDotParams);
        versionTitleRow.addView(versionDot);

        TextView versionTitle = new TextView(this);
        versionTitle.setText("版本信息");
        versionTitle.setTextSize(14);
        versionTitle.setTypeface(Typeface.DEFAULT_BOLD);
        versionTitle.setTextColor(COLOR_TEXT_PRIMARY);
        versionTitleRow.addView(versionTitle);
        versionCard.addView(versionTitleRow);

        // 版本内容
        final TextView versionContent = new TextView(this);
        versionContent.setText("正在加载...");
        versionContent.setTextSize(13);
        versionContent.setTextColor(COLOR_TEXT_SECONDARY);
        versionContent.setLineSpacing(dp(3), 1);
        versionCard.addView(versionContent);

        // 版本状态标签（初始隐藏）
        final TextView versionBadge = new TextView(this);
        versionBadge.setVisibility(View.GONE);
        versionBadge.setTextSize(11);
        versionBadge.setTypeface(Typeface.DEFAULT_BOLD);
        versionBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        badgeParams.setMargins(0, dp(8), 0, 0);
        versionBadge.setLayoutParams(badgeParams);
        versionCard.addView(versionBadge);

        container.addView(versionCard);

        // ---- 分割线 ----
        View divider = new View(this);
        divider.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        divider.setLayoutParams(dividerParams);
        container.addView(divider);

        // ---- 登录卡片 ----
        LinearLayout loginCard = createCard();

        // 登录标题
        TextView loginTitle = new TextView(this);
        loginTitle.setText("卡密验证");
        loginTitle.setTextSize(14);
        loginTitle.setTypeface(Typeface.DEFAULT_BOLD);
        loginTitle.setTextColor(COLOR_TEXT_PRIMARY);
        loginTitle.setPadding(0, 0, 0, dp(12));
        loginCard.addView(loginTitle);

        // 卡密输入框
        final EditText kamiInput = new EditText(this);
        kamiInput.setHint("请输入卡密");
        kamiInput.setHintTextColor(COLOR_TEXT_HINT);
        kamiInput.setTextSize(14);
        kamiInput.setTextColor(COLOR_TEXT_PRIMARY);
        kamiInput.setSingleLine(true);
        kamiInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(COLOR_INPUT_BG);
        inputBg.setCornerRadius(dp(10));
        inputBg.setStroke(dp(1), COLOR_INPUT_BORDER);
        kamiInput.setBackground(inputBg);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        kamiInput.setLayoutParams(inputParams);
        loginCard.addView(kamiInput);

        // 登录按钮
        final Button loginBtn = new Button(this);
        loginBtn.setText("登  录");
        loginBtn.setTextSize(15);
        loginBtn.setTypeface(Typeface.DEFAULT_BOLD);
        loginBtn.setTextColor(Color.WHITE);
        loginBtn.setAllCaps(false);
        loginBtn.setBackground(createButtonDrawable(COLOR_PRIMARY, COLOR_PRIMARY_DARK));
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        btnParams.setMargins(0, dp(14), 0, 0);
        loginBtn.setLayoutParams(btnParams);
        loginCard.addView(loginBtn);

        // 状态提示
        final TextView statusText = new TextView(this);
        statusText.setText("");
        statusText.setTextSize(12);
        statusText.setTextColor(COLOR_TEXT_SECONDARY);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, dp(10), 0, 0);
        statusText.setVisibility(View.GONE);
        loginCard.addView(statusText);

        container.addView(loginCard);

        // ---- 底部版权 ----
        TextView copyright = new TextView(this);
        copyright.setText("Powered by T3验证  ·  t3yanzheng.com");
        copyright.setTextSize(11);
        copyright.setTextColor(COLOR_TEXT_HINT);
        copyright.setGravity(Gravity.CENTER);
        copyright.setPadding(0, dp(16), 0, dp(4));
        container.addView(copyright);

        scrollView.addView(container);

        // ---- 创建全屏对话框 ----
        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_NoActionBar);
        builder.setView(scrollView);
        builder.setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();

        // 需要在匿名内部类中引用
        final AlertDialog finalDialog = dialog;

        // 设置状态栏
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow != null) {
            dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            dialogWindow.setStatusBarColor(COLOR_BG);
            dialogWindow.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        // ---- 后台加载数据 ----
        new Thread(new Runnable() {
            @Override
            public void run() {
                // 获取公告
                final T3Verify.T3NoticeResult noticeResult = verify.getNotice();
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (noticeResult.success) {
                            noticeContent.setText(noticeResult.notice);
                        } else {
                            noticeContent.setText("获取失败: " + noticeResult.error);
                            noticeContent.setTextColor(COLOR_ERROR);
                        }
                    }
                });

                // 获取版本号
                final T3Verify.T3VersionResult versionResult = verify.getLatestVersion();
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (versionResult.success) {
                            String remoteVer = versionResult.version;
                            versionContent.setText("本地版本  " + LOCAL_VERSION + "   |   最新版本  " + remoteVer);

                            versionBadge.setVisibility(View.VISIBLE);
                            if (remoteVer != null && remoteVer.compareTo(LOCAL_VERSION) > 0) {
                                versionBadge.setText("有新版本可用");
                                versionBadge.setTextColor(Color.WHITE);
                                GradientDrawable bg = new GradientDrawable();
                                bg.setColor(COLOR_WARNING);
                                bg.setCornerRadius(dp(12));
                                versionBadge.setBackground(bg);
                            } else {
                                versionBadge.setText("已是最新版本");
                                versionBadge.setTextColor(Color.WHITE);
                                GradientDrawable bg = new GradientDrawable();
                                bg.setColor(COLOR_SUCCESS);
                                bg.setCornerRadius(dp(12));
                                versionBadge.setBackground(bg);
                            }
                        } else {
                            versionContent.setText("获取失败: " + versionResult.error);
                            versionContent.setTextColor(COLOR_ERROR);
                        }
                    }
                });
            }
        }).start();

        // ---- 登录事件 ----
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String kami = kamiInput.getText().toString().trim();
                if (kami.isEmpty()) {
                    Toast.makeText(MainActivity.this, "请输入卡密", Toast.LENGTH_SHORT).show();
                    return;
                }

                loginBtn.setEnabled(false);
                loginBtn.setText("验证中...");
                statusText.setVisibility(View.VISIBLE);
                statusText.setText("正在连接服务器...");
                statusText.setTextColor(COLOR_PRIMARY);

                final String machineCode = getDeviceId();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final T3Verify.T3LoginResult result = verify.login(kami, machineCode);
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (result.success) {
                                    saveCard(kami);
                                    finalDialog.dismiss();
                                    onLoginSuccess(kami, result);
                                } else {
                                    loginBtn.setEnabled(true);
                                    loginBtn.setText("登  录");
                                    loginBtn.setBackground(createButtonDrawable(COLOR_PRIMARY, COLOR_PRIMARY_DARK));
                                    statusText.setVisibility(View.VISIBLE);
                                    statusText.setText(result.error);
                                    statusText.setTextColor(COLOR_ERROR);
                                }
                            }
                        });
                    }
                }).start();
            }
        });
    }

    // ============================================================
    // 登录成功界面
    // ============================================================

    private void onLoginSuccess(String kami, T3Verify.T3LoginResult result) {
        // 保存登录状态用于心跳
        this.savedCard = kami;
        this.savedStateCode = result.statecode;

        // 启动心跳定时器
        startHeartbeat();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(40), dp(40), dp(40), dp(40));
        root.setBackgroundColor(COLOR_BG);
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // 成功图标（圆形带对勾的视觉）
        TextView successIcon = new TextView(this);
        successIcon.setText("OK");
        successIcon.setTextSize(20);
        successIcon.setTypeface(Typeface.DEFAULT_BOLD);
        successIcon.setTextColor(Color.WHITE);
        successIcon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(COLOR_SUCCESS);
        successIcon.setBackground(iconBg);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(64), dp(64));
        iconParams.gravity = Gravity.CENTER_HORIZONTAL;
        successIcon.setLayoutParams(iconParams);
        root.addView(successIcon);

        // 成功标题
        TextView successTitle = new TextView(this);
        successTitle.setText("验证通过");
        successTitle.setTextSize(22);
        successTitle.setTypeface(Typeface.DEFAULT_BOLD);
        successTitle.setTextColor(COLOR_TEXT_PRIMARY);
        successTitle.setGravity(Gravity.CENTER);
        successTitle.setPadding(0, dp(20), 0, dp(24));
        root.addView(successTitle);

        // 信息卡片
        LinearLayout infoCard = createCard();

        // 到期时间
        addInfoRow(infoCard, "到期时间", result.endTime);
        // 分割
        View line = new View(this);
        line.setBackgroundColor(COLOR_DIVIDER);
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lineParams.setMargins(0, dp(10), 0, dp(10));
        line.setLayoutParams(lineParams);
        infoCard.addView(line);
        // 卡密ID
        addInfoRow(infoCard, "卡密 ID", result.id);

        root.addView(infoCard);

        // 提示
        TextView tip = new TextView(this);
        tip.setText("开发者可在 onLoginSuccess() 中添加业务逻辑");
        tip.setTextSize(12);
        tip.setTextColor(COLOR_TEXT_HINT);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(20), 0, 0);
        root.addView(tip);

        setContentView(root);
    }

    // ============================================================
    // 心跳验证（每60秒一次，连续5次失败强制退出）
    // ============================================================

    private void startHeartbeat() {
        heartbeatHandler = new Handler(Looper.getMainLooper());
        heartbeatFailCount = 0;
        heartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final T3Verify.T3Result hbResult = verify.heartbeat(savedCard, savedStateCode);
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (hbResult.success) {
                                    heartbeatFailCount = 0;
                                } else {
                                    heartbeatFailCount++;
                                    if (heartbeatFailCount >= MAX_HEARTBEAT_FAIL) {
                                        // 连续失败5次，清除卡密并强制退出
                                        clearCard();
                                        Toast.makeText(MainActivity.this,
                                                "心跳验证连续失败 " + MAX_HEARTBEAT_FAIL + " 次，程序退出",
                                                Toast.LENGTH_LONG).show();
                                        finishAffinity();
                                        System.exit(0);
                                        return;
                                    }
                                }
                                // 继续下一次心跳
                                heartbeatHandler.postDelayed(heartbeatRunnable, HEARTBEAT_INTERVAL);
                            }
                        });
                    }
                }).start();
            }
        };
        // 第一次心跳延迟60秒后执行
        heartbeatHandler.postDelayed(heartbeatRunnable, HEARTBEAT_INTERVAL);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (heartbeatHandler != null && heartbeatRunnable != null) {
            heartbeatHandler.removeCallbacks(heartbeatRunnable);
        }
    }

    // ============================================================
    // UI 工具方法
    // ============================================================

    /** 创建白色圆角卡片容器 */
    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(COLOR_CARD);
        cardBg.setCornerRadius(dp(12));

        card.setBackground(cardBg);
        // 模拟阴影效果
        card.setElevation(dp(2));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cardParams);
        return card;
    }

    /** 创建带按压效果的按钮背景 */
    private StateListDrawable createButtonDrawable(int normalColor, int pressedColor) {
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(normalColor);
        normal.setCornerRadius(dp(10));

        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(pressedColor);
        pressed.setCornerRadius(dp(10));

        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[]{android.R.attr.state_pressed}, pressed);
        stateList.addState(new int[]{}, normal);
        return stateList;
    }

    /** 添加信息行（标签 + 值） */
    private void addInfoRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(13);
        labelView.setTextColor(COLOR_TEXT_SECONDARY);
        labelView.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(labelView);

        TextView valueView = new TextView(this);
        valueView.setText(value != null ? value : "-");
        valueView.setTextSize(13);
        valueView.setTypeface(Typeface.DEFAULT_BOLD);
        valueView.setTextColor(COLOR_TEXT_PRIMARY);
        valueView.setGravity(Gravity.END);
        row.addView(valueView);

        parent.addView(row);
    }

    /** 获取设备唯一标识 */
    private String getDeviceId() {
        try {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId != null && !androidId.isEmpty()) {
                return androidId;
            }
        } catch (Exception e) {
            // ignore
        }
        return T3Verify.getMachineCode();
    }

    /** dp转px */
    private int dp(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
